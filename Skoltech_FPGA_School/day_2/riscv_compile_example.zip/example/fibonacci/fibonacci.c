int main()
{
    int N = 20;
    int a[N];
    a[0] = 1;
    a[1] = 1;

// main loop
    for (int i = 2; i < N; ++i)
    {
      a[i] = a[i - 1] + a[i - 2];
    }
    return 0;
}