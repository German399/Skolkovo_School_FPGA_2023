/// Copyright by Syntacore LLC © 2016, 2017. See LICENSE for details
/// @file       <sc_print.h>
///

#ifndef SC_PRINT_H
#define SC_PRINT_H

extern int sc_printf(const char* fmt, ...);

#endif // SC_PRINT_H