#include "sc_print.h"

int main()
{
    sc_printf("Hello from SCR1!\n");
    return 0;
}