
int myFunc (int a, int b)
{
  return a + b;
}

int main()
{
    int N = 20;
    int a[N];
    a[0] = 1;
    a[1] = 1;

// main loop
    for (int i = 2; i < N; ++i)
    {
      a[i] = myFunc(a[i - 1], a[i - 2]);
    }
    return a[N-1];
}